import { ComponentProps } from "react";

type Props = {
  field: string;
  value: string;
} & ComponentProps<"div">;

export default function UserInfoCart({ field, value }: Props) {
  return (
    <div className="flex gap-1 border border-spacing-1 border-gray-400">
      <h4 className="min-w-[20ch] border-r-2 border-gray-400">{field}</h4> : <h4>{value}</h4>
    </div>
  );
}
