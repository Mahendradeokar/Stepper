export const TRAVEL_PREFERENCE = [
  "Beach vacation",
  "Mountain retreat",
  "Cultural exploration",
  "Adventure travel",
  "City getaway",
];

export const COUNTRY_OF_ORIGIN = [
  "China",
  "India",
  "United States",
  "Indonesia",
  "Pakistan",
  "Brazil",
  "Nigeria",
  "Bangladesh",
];
