"use client";

import UserInfoCart from "@/components/UserInfoCard";
import { getInterestInfo, getPersonalInfo, getUserSignUpDetails } from "@/redux";
import { useSelector } from "react-redux";

export default function userInfo() {
  const signUpInfo = useSelector(getUserSignUpDetails);
  const personalInfo = useSelector(getPersonalInfo);
  const interestInfo = useSelector(getInterestInfo);
  return (
    <div className="max-w-[850px] mx-auto space-y-2 shadow-lg">
      <h1 className="text-center text-lg font-bold">SignUp info</h1>
      <div className="grid mx-auto p-6 grid-cols-1">
        {Object.entries(signUpInfo).map(([field, value]) => {
          return <UserInfoCart field={field} value={value} key={field} />;
        })}
      </div>

      <h1 className="text-center text-lg font-bold">Personal info</h1>
      <div className="grid mx-auto p-6 grid-cols-1">
        {Object.entries(personalInfo).map(([field, value]) => {
          return <UserInfoCart field={field} value={value} key={field} />;
        })}
      </div>

      <h1 className="text-center text-lg font-bold">Interest info</h1>
      <div className="grid mx-auto p-6 grid-cols-1">
        {Object.entries(interestInfo).map(([field, value]) => {
          if (Array.isArray(value)) {
            return (
              <UserInfoCart field={field} value={value.join(",")} key={field} />
            );
          }
          return <UserInfoCart field={field} value={value} key={field} />;
        })}
      </div>
    </div>
  );
}
